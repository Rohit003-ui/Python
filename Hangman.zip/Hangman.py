import random

def hangman():
    words = ['python', 'hangman', 'programming', 'challenge', 'developer']
    guessed_letters = set()
    
    while words:
        word = random.choice(words) 
        words.remove(word)  
        attempts_left = 6
        guessed_letters.clear()  

        print("Welcome to Hangman!")
        print("Try to guess the word!")

        while attempts_left > 0:
            display_word = ''.join(letter if letter in guessed_letters else '_' for letter in word)
            print("\n" + display_word)
            print(f"Attempts left: {attempts_left}")

            guess = input("Guess a letter: ").lower()

            if guess in guessed_letters:
                print("You've already guessed that letter.")
                continue

            guessed_letters.add(guess)

            if guess in word:
                print("Good guess!")
            else:
                print("Wrong guess.")
                attempts_left -= 1

            if all(letter in guessed_letters for letter in word):
                print(f"\nCongratulations! You've guessed the word: {word}")
                break
        else:
            print(f"\nOut of attempts! The word was: {word}")

    print("\nNo more words left to guess. Thanks for playing!")

if __name__ == "__main__":
    hangman()
